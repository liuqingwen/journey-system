package share.lambda.test;

import org.junit.Test;
import share.lambda.bean.UserInfo;

import java.time.LocalDate;
import java.util.function.Consumer;

/**
 * @author liuqingwen
 * @date 2018/4/23.
 */
public class DesignModeTest {

//    策略模式 模板模式

    @Test
    public void test() {

        UserInfo userInfo = UserFactoryBean.create(1, "张三", (byte)1, 20, LocalDate.of(1990, 2, 21),"北京", 1, 100.00);
        System.out.println(userInfo);
    }


}



class UserFactoryBean {

    public static UserInfo create(Integer id, String username, Byte sex, Integer age, LocalDate birthday, String area, Integer areaId, Double consumptionAmount) {

        return ((UserSupplier<UserInfo>)(Integer id1, String username1, Byte sex1, Integer age1, LocalDate birthday1,
                                         String area1, Integer areaId1, Double consumptionAmount1)
                -> UserInfo.create(id1, username1, sex1, age1, birthday1, area1, areaId1, consumptionAmount1))
                .get(id, username, sex, age, birthday, area, areaId, consumptionAmount);
    }

    // 模板模式
    public UserInfo filter(UserInfo userInfo, Consumer<UserInfo> consumer) {
        userInfo = UserInfo.create(1, "张三", (byte)1, 20, LocalDate.of(1990, 2, 21),"北京", 1, 100.00);
        consumer.accept(userInfo);
        return userInfo;
    }
}

@FunctionalInterface
interface UserSupplier<T> {

    T get(Integer id, String username, Byte sex, Integer age, LocalDate birthday, String area, Integer areaId, Double consumptionAmount);

}

