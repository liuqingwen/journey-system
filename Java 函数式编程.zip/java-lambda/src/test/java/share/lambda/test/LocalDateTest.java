package share.lambda.test;

import org.junit.Test;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;

/**
 * @author liuqingwen
 * @date 2018/4/24.
 */
public class LocalDateTest {

    @Test
    public void test() {

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");

        LocalDate localDate = LocalDate.of(2018, 4, 24);
        System.out.println(localDate);
        System.out.println(localDate.format(dateTimeFormatter));
//        System.out.println(localDate.format(DateTimeFormatter.ofPattern("YYYY-MM-dd HH:mm:ss")));

        LocalDate parse = LocalDate.parse("2018/04/24", dateTimeFormatter);
        System.out.println("parse date = " + parse);


//      1970-01-01 00:00:00 开始
        LocalDate localDate1 = LocalDate.ofEpochDay(10);
        System.out.println(localDate1.format(dateTimeFormatter));

        localDate.minus(10, ChronoUnit.DAYS);
        System.out.println(localDate.format(dateTimeFormatter));

        LocalDate minus = localDate.minus(10, ChronoUnit.DAYS);
        System.out.println(minus.format(dateTimeFormatter));

//        localDate.minusDays()
//        localDate.minusMonths()
//        localDate.minusWeeks()


        LocalDate localDate2 = localDate.withDayOfMonth(11);
        System.out.println("localDate2 = " + localDate2);


        DayOfWeek dayOfWeek = localDate.getDayOfWeek();
        System.out.println(dayOfWeek);


        // 当前月份有多少天
        int i = localDate1.lengthOfMonth();
        System.out.println(i);
        // 同上面一样 更多变
//        localDate1.range(ChronoField.DAY_OF_MONTH)


        Period of = Period.of(2018, 04, 24);
        System.out.println(of);
        System.out.println(of.getDays());


        Period between = Period.between(localDate, localDate2);
        System.out.println(between);
        System.out.println(between.getDays());
        System.out.println(between.getMonths());


        Period between1 = Period.between(LocalDate.of(2014, 07, 14), LocalDate.now());
        System.out.printf("%s 年 %s 月 %s 日", between1.getYears(), between1.getMonths(), between1.getDays());

    }

}
