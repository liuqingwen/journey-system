package share.lambda.test;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.junit.Test;
import share.lambda.bean.UserInfo;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Predicate;
import java.util.function.ToIntFunction;
import java.util.regex.Pattern;

import static java.util.stream.Collectors.*;

/**
 * @author liuqingwen
 * @date 2018/4/20.
 */
public class StreamTest {

    // 参考资料
    // http://ifeve.com/java8-stream-%E4%B8%ADspliterator%E7%9A%84%E4%BD%BF%E7%94%A8%E4%B8%80/
    // https://www.ibm.com/developerworks/cn/java/j-java-streams-1-brian-goetz/index.html?ca=drs-

    ArrayList<UserInfo> userInfos = null;
    {
        userInfos = Lists.newArrayList(
                UserInfo.create(1, "张三", (byte)1, 20, LocalDate.of(1990, 2, 21),"北京", 1, 100.00),
                UserInfo.create(4, "张四", (byte)1, 16, LocalDate.of(1985, 7, 1),"北京", 4, 400.00),
                UserInfo.create(5, "张五", (byte)2, 30, LocalDate.of(1996, 12, 7),"北京", 5, 500.00),
                UserInfo.create(2, "李四", (byte)2, 21, LocalDate.of(1990, 3, 25),"深圳", 2, 200.00),
                UserInfo.create(3, "赵五", (byte)1, 13, LocalDate.of(1990, 7, 17),"杭州", 3, 300.00));
    }

    @Test
    public void test() {

        ExecutorService executorService = Executors.newFixedThreadPool(100);
        executorService.execute(() -> System.out.println("我是Runnable的匿名类"));
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                System.out.println("我是Runnable的匿名类");
            }
        });

        // 创建 比较器
        Comparator<UserInfo> comparator2 = (UserInfo o1, UserInfo o2) -> o1.getAge().intValue() - o2.getAge().intValue();
        Comparator<UserInfo> comparator3 = (o1, o2) -> o1.getAge().intValue() - o2.getAge().intValue();
        Comparator<UserInfo> comparing1 = Comparator.comparing(UserInfo::getAge);
        Comparator<UserInfo> comparator = new Comparator<UserInfo>() {
            @Override
            public int compare(UserInfo o1, UserInfo o2) {
                return o1.getAge().intValue() - o2.getAge().intValue();
            }
        };

        System.out.println(userInfos.stream().mapToInt(new ToIntFunction<UserInfo>(){
            @Override
            public int applyAsInt(UserInfo userInfo) {
                return 1;
            }
        }).count());
        System.out.println(userInfos.stream().mapToInt(UserInfo::getId).count());
        System.out.println(userInfos.stream().map(userInfo -> 1).reduce(0, Integer::sum)); // Integer::sum == (int a, int b) -> a + b;
        Optional reduce = userInfos.stream().map(userInfo -> 1).reduce(Integer::sum);
        System.out.println(reduce.orElse(0));
    }

    // 按照地区分组
    @Test
    public void test2() {

        Map<String, List<UserInfo>> collect = userInfos.stream().collect(groupingBy(UserInfo::getArea));
        System.out.println(collect);


//        Before Java 8

        Map<String, List<UserInfo>> map = Maps.newHashMap();
        for (UserInfo userInfo : userInfos) {
            if (userInfo == null) {
                String area = userInfo.getArea();
                if (map.get(area) == null) {
                    map.put(area, Lists.newArrayList(userInfo));
                } else {
                    map.get(area).add(userInfo);
                }
            }
        }

    }

    // 按照地区分组，并算出每个地区用户数量
    @Test
    public void test2_1() {

        Map<String, Long> collect = userInfos.stream().collect(groupingBy(UserInfo::getArea, counting()));
        System.out.print(collect);

//        userInfos.stream().count(); // 数量
    }

    // 按照性别分区 // 1男 2女 下面Map集合 就是true为男性，false为女性
    @Test
    public void test2_2() {

        Map<Boolean, List<UserInfo>> collect1 = userInfos.stream().collect(partitioningBy(userInfo -> userInfo.getSex() == 1));
        System.out.println(collect1);
    }

    @Test
    public void test2_3() {

        HashMap<String, Object> objectObjectHashMap = Maps.newHashMap();
        Object chen = objectObjectHashMap.putIfAbsent("chen", 1);
        Object chen1 = objectObjectHashMap.putIfAbsent("chen", 2);
        System.out.println(chen);
        System.out.println(chen1);
        Object chen2 = objectObjectHashMap.compute("chen", (key1, key2) -> key1);
        System.out.println(chen2);


//        userInfos.stream().collect(HashMap::new, (HashMap<Boolean, List<UserInfo>> listHashMap, UserInfo userInfo) -> {
//            listHashMap.putIfAbsent()
//        }));
    }

    // 在用户集合中，选出年龄最大的男性，并且消费金额要大于500
    @Test
    public void test3() {

        Optional<UserInfo> collect = userInfos.stream().
                filter(userInfo -> userInfo.getConsumptionAmount() > 100).
                filter(userInfo -> userInfo.getSex() == 1).collect(maxBy(Comparator.comparing(UserInfo::getAge)));
        System.out.println(collect.orElseGet(() -> new UserInfo()));
    }

    // 在用户集合中，选出消费大于100.00，按照年龄排序倒序，列出所有名字
    @Test
    public void test3_1() {

        List<String> collect = userInfos.stream().filter(userInfo -> userInfo.getConsumptionAmount() > 100.00).
                sorted(Comparator.comparing(UserInfo::getAge).reversed()).map(UserInfo::getUsername).collect(toList());
        System.out.println(collect);
    }

    // 按照地区分组，计算出每个地区，消费总额
    @Test
    public void test4() {

        Map<String, Double> collect = userInfos.stream().collect(groupingBy(UserInfo::getArea, summingDouble(UserInfo::getConsumptionAmount)));
        System.out.println(collect);
    }

    // 按照地区分组，计算出每个地区，男性消费总额，女性消费总额
    @Test
    public void test4_1() {

        Map<String, Map<Byte, Double>> collect = userInfos.stream().collect(groupingBy(UserInfo::getArea,
                groupingBy(UserInfo::getSex, summingDouble(UserInfo::getConsumptionAmount))));
        System.out.println(collect);
    }

    // 按照地区分组，计算出超过18岁的，男性消费总额，女性消费总额
    @Test
    public void test4_2() {

        Predicate predicate = userInfo -> userInfo != null;
        Predicate<UserInfo> predicate1 = (UserInfo userInfo) -> userInfo.getAge() > 18;
        predicate.and(predicate1);

//        userInfos.stream().filter(userInfo -> userInfo != null && userInfo.getAge() > 18)
        userInfos.stream().filter(((Predicate<UserInfo>)(userInfo -> userInfo != null)).and(userInfo -> userInfo.getAge() > 18)).
                collect(groupingBy(UserInfo::getArea, groupingBy(UserInfo::getSex, summingDouble(UserInfo::getConsumptionAmount))));
    }

    @Test
    public void test4_3() { // 包含多总 统计方式

        Map<String, DoubleSummaryStatistics> collect = userInfos.stream().collect(groupingBy(UserInfo::getArea, summarizingDouble(UserInfo::getConsumptionAmount)));
        System.out.println(collect);
    }

    // 计算所有用户消费总金额
    @Test
    public void test5() {

        double sum = userInfos.stream().mapToDouble(UserInfo::getConsumptionAmount).sum();
        System.out.println(sum);


        userInfos.stream().collect(toMap(UserInfo::getId, userInfo -> userInfo, (key1, key2) -> key1));
    }

    @Test
    public void test5_1() { // 包含多总 统计方式

        DoubleSummaryStatistics doubleSummaryStatistics = userInfos.stream().mapToDouble(UserInfo::getConsumptionAmount).summaryStatistics();
        System.out.println(doubleSummaryStatistics);
    }

    final String dealStr = "%67%#$@23&1";

    // %67%#$@23&1
    // (1*2$9_=0=+2%#%&*jhoiu4lk2l1k4j5hl23kh5l
    // 计算字符串数字和
    @Test
    public void test6() {

        List<String> collect = Pattern.compile("").splitAsStream(dealStr).collect(toList());
        System.out.println(collect);

//        System.out.println("s".charAt(0));

        // 第三个参数，只有在并发条件下，才会有用  <U> U reduce(U identity,
        //                 BiFunction<U, ? super T, U> accumulator, [ə'kjumjəletɚ] 累加器
        //                 BinaryOperator<U> combiner) [kəm'bainə] 组合器

        // combiner 合并
        IntCounter reduce = Pattern.compile("").splitAsStream(dealStr).reduce(new IntCounter(String.valueOf(0), 0, true),
                IntCounter::accumulator, IntCounter::combiner);
        System.out.println(reduce.isFullNumber ? reduce.result : reduce.result + Integer.parseInt(reduce.counter));

//        Pattern.compile("").splitAsStream(dealStr).reduce(HashSet::new, HashSet::add, HashSet::addAll);
        HashSet<Object> collect1 = Pattern.compile("").splitAsStream(dealStr).parallel().collect(HashSet::new, HashSet::add, HashSet::addAll);
        System.out.println(collect1);


    }

    public class IntCounter {

        private String counter;
        private Integer result;
        private Boolean isFullNumber;

        public IntCounter(String counter, Integer result, Boolean isFullNumber) {
            this.counter = counter;
            this.result = result;
            this.isFullNumber = isFullNumber;
        }

        public IntCounter accumulator(String str) {

            if (Character.isDigit(str.charAt(0))) {
                return new IntCounter(counter + str, result, false);
            } else {
                return isFullNumber ? new IntCounter("", result, true) : new IntCounter("", result + Integer.parseInt(counter), true);
            }
        }

        // 只要在并发条件下，才会调用
        public IntCounter combiner(IntCounter counter) {
            return new IntCounter(counter.counter + this.counter, counter.result + this.result, counter.isFullNumber);
        }

        @Override
        public String toString() {
            return "IntCounter{" +
                    "counter='" + counter + '\'' +
                    ", result=" + result +
                    ", isFullNumber=" + isFullNumber +
                    '}';
        }
    }

    @Test
    public void test7() {

        System.out.println(Lists.newArrayList(1,2,3,4).stream().collect(reducing(0, i -> i, Integer::sum)));
    }
}
