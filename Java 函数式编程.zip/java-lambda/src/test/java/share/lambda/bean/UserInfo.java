package share.lambda.bean;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author liuqingwen
 * @date 2018/4/20.
 */
public class UserInfo implements Serializable {

    private static final long serialVersionUID = 1237914503435225345L;

    private Integer id;// 编号
    private String username;// 用户名字
    private Byte sex;// 性别 -> 1 男 2 女
    private Integer age;// 年龄
    private LocalDate birthday;// 出生日期
    private String area;// 地区
    private Integer areaId;// 地区ID
    private Double consumptionAmount;// 消费金额

    public static UserInfo create(Integer id, String username, Byte sex, Integer age, LocalDate birthday, String area, Integer areaId, Double consumptionAmount) {
        UserInfo userInfo = new UserInfo();
        userInfo.setId(id);
        userInfo.setUsername(username);
        userInfo.setSex(sex);
        userInfo.setAge(age);
        userInfo.setBirthday(birthday);
        userInfo.setArea(area);
        userInfo.setAreaId(areaId);
        userInfo.setConsumptionAmount(consumptionAmount);
        return userInfo;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Byte getSex() {
        return sex;
    }

    public void setSex(Byte sex) {
        this.sex = sex;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public LocalDate getBirthday() {
        return birthday;
    }

    public void setBirthday(LocalDate birthday) {
        this.birthday = birthday;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public Integer getAreaId() {
        return areaId;
    }

    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    public Double getConsumptionAmount() {
        return consumptionAmount;
    }

    public void setConsumptionAmount(Double consumptionAmount) {
        this.consumptionAmount = consumptionAmount;
    }

    @Override
    public String toString() {
        return "UserInfo{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", sex=" + sex +
                ", age=" + age +
                ", birthday=" + birthday +
                ", area='" + area + '\'' +
                ", areaId=" + areaId +
                ", consumptionAmount=" + consumptionAmount +
                '}';
    }
}
